import json
import boto3
import time
import os

def lambda_handler(event, context):
    
    try:
        aws_jobdefinition = os.environ['aws_jobdefinition']
        aws_jobqueue = os.environ['aws_jobqueue']
        aws_accesskeyid = json.loads(event['body'])['aws_access_key_id']
        aws_accesskeysecret = json.loads(event['body'])['aws_secret_access_key']
        aws_s3reportbucket = json.loads(event['body'])['aws_s3reportbucket']
            
        timestr = time.strftime("%Y%m%d-%H%M%S")
        client = boto3.client('batch')
        varjobName = aws_jobqueue+'-'+timestr
        response = client.submit_job(
            jobName=varjobName,
            jobQueue=aws_jobqueue,
            jobDefinition=aws_jobdefinition,
            containerOverrides={
                
                'environment': [
                    {
                        'name': 'AWS_ACCESS_KEY_ID',
                        'value': aws_accesskeyid
                    },
                    {
                        'name': 'AWS_SECRET_ACCESS_KEY',
                        'value': aws_accesskeysecret
                    },
                    {
                        'name': 'S3_BUCKET_NAME',
                        'value': aws_s3reportbucket
                    }
                ]
            }
        )
        
        print(response)
        
        return {
            'statusCode': 200,
            'headers': {
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'OPTIONS,POST'
            },
            'body': json.dumps('Submitted with jobName '+ varjobName)
        }
        
    except Exception as e:
        return exception_handler(e)
    
def exception_handler(e):
    # exception to status code mapping goes here...
    status_code = 400
    return {
        'statusCode': status_code,
            'headers': {
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'OPTIONS,POST'
            },
        'body': json.dumps(str(e))
    }
